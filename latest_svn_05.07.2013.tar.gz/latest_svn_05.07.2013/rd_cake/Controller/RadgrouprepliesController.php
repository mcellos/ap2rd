<?php
class RadgrouprepliesController extends AppController {

    var $scaffold;

}
?>
