<?php
App::uses('AppController', 'Controller');

class OpenvpnClientsController extends AppController {

    var $scaffold;

}
