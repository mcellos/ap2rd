<?php
class RadgroupchecksController extends AppController {

    var $scaffold;

}
?>
