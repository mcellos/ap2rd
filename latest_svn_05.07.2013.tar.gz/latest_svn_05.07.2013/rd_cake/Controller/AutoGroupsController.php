<?php
class AutoGroupsController extends AppController {

    var $scaffold;

}
?>
