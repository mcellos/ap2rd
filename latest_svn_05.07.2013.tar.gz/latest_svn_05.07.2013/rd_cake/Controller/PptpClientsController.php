<?php
App::uses('AppController', 'Controller');

class PptpClientsController extends AppController {

    var $scaffold;

}
