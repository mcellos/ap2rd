<?php
class AutoContactsController extends AppController {

    var $scaffold;

}
?>
