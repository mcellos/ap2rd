<?php
// app/Model/Check.php
class Check extends AppModel {
    public $name        = 'Check';
    public $actsAs      = array('Containable');
}
?>
