<?php
App::uses('AppModel', 'Model');
class AutoContact extends AppModel {

    public $actsAs = array('Containable');
}

?>
