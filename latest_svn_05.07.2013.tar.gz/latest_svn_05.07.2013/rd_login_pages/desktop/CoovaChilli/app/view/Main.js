Ext.define("CoovaLogin.view.Main", {
    extend: 'Ext.Component',
    html: 'Hello, World!!'
});