$CustomManifest = {
    widgets: []
};