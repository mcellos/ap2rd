Ext.define('Rd.patch.ExtJS411aPatch', {
    requires: [
        'Rd.patch.form.SubmitFix',
        'Rd.patch.view.GridLoadMask',
        'Rd.patch.window.Window',
        'Rd.patch.data.Store'
    ]
});
