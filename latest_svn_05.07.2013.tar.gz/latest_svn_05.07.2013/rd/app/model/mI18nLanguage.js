Ext.define('Rd.model.mI18nLanguage', {
    extend: 'Ext.data.Model',
    fields: ['id', 'name','iso_code','rtl']
});
