Ext.define('Rd.model.mI18nCountry', {
    extend: 'Ext.data.Model',
    fields: ['id', 'name', 'iso_code', 'icon_file']
});
