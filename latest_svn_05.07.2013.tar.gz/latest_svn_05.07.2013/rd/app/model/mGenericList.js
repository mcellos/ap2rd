Ext.define('Rd.model.mGenericList', {
    extend: 'Ext.data.Model',
    fields: ['id','text']
});
