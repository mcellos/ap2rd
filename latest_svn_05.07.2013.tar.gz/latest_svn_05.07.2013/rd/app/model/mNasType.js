Ext.define('Rd.model.mNasType', {
    extend: 'Ext.data.Model',
    fields: [
         {name: 'id',           type: 'string'  },
         {name: 'name',         type: 'string'  },
         {name: 'active',       type: 'bool'    }
        ]
});
