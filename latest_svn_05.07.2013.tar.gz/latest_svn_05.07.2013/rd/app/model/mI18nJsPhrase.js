Ext.define('Rd.model.mI18nJsPhrase', {
    extend: 'Ext.data.Model',
    fields: ['id', 'key','comment','english','translated','key_id']
});
