Ext.define('Rd.model.mApRealms', {
    extend: 'Ext.data.Model',
    fields: ['id','name', 'create','read','update','delete']
});
