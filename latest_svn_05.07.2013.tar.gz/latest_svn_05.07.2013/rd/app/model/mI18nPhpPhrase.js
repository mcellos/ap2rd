Ext.define('Rd.model.mI18nPhpPhrase', {
    extend: 'Ext.data.Model',
    fields: ['id','comment', 'msgid','msgstr']
});
