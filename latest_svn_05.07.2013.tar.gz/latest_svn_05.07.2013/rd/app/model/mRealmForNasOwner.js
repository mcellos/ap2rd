Ext.define('Rd.model.mRealmForNasOwner', {
    extend: 'Ext.data.Model',
    fields: ['id','name','selected']
});
