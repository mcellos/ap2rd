Ext.define('Rd.model.mDynamicPage', {
    extend: 'Ext.data.Model',
    fields: [
         {name: 'id',           type: 'int'     },
         {name: 'name',         type: 'string'  },
         {name: 'content',      type: 'string'  }
        ]
});
