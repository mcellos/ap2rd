Ext.define('Rd.model.mDynamicPhoto', {
    extend: 'Ext.data.Model',
    fields: [
            'id', 'dynamic_detail_id', 'title', 'description','file_name', 'img'
        ]
});
