Ext.define('Rd.model.mWallpaper', {
    extend: 'Ext.data.Model',
    fields: [
            'id', 'file', 'r_dir', 'img'
        ]
});
