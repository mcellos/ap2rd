Ext.define('Rd.model.mDynamicAttribute', {
    extend: 'Ext.data.Model',
    fields: [
         {name: 'id',           type: 'string'  },
         {name: 'name',         type: 'string'  },
         {name: 'active',       type: 'bool'    }
        ]
});
