Ext.define('Rd.model.mVendor', {
    extend: 'Ext.data.Model',
    fields: [
            'id', 'name'
        ]
});
