Ext.define('Rd.model.mAttribute', {
    extend: 'Ext.data.Model',
    fields: [
            'id', 'name'
        ]
});
