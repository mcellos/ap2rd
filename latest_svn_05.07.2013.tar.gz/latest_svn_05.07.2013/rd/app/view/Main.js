Ext.define("Rd.view.Main", {
    extend: 'Ext.Component',
    html: 'Hello, World!!'
});