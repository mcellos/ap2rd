Ext.define('Rd.view.Viewport', {
    extend: 'Ext.container.Viewport',
    alias: 'widget.vp',
    layout: 'fit'
});
