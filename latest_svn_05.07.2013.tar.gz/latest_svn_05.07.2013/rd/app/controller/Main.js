Ext.define('Rd.controller.Main', {
    extend: 'Ext.app.Controller'
});