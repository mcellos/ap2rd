Ext.define('Rd.store.sDynamicAttributes', {
    extend: 'Ext.data.Store',
    model: 'Rd.model.mDynamicAttribute',
    proxy: {
            type    : 'ajax',
            format  : 'json',
            batchActions: true, 
            url     : '/cake2/rd_cake/nas/dynamic_attributes.json',
            reader: {
                type: 'json',
                root: 'items',
                messageProperty: 'message'
            }
    },
    autoLoad: true
});
