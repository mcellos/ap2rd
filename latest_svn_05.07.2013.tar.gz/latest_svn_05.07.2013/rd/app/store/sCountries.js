Ext.define('Rd.store.sCountries', {
    extend: 'Ext.data.Store',
    model: 'Rd.model.mI18nCountry',
    proxy: {
            'type'  :'rest',
            'url'   : '/cake2/rd_cake/countries',
            format  : 'json', 
            reader: {
                type: 'json',
                root: 'items'
            }  
    },
    autoLoad: true
});
